/**
  * Created by randy on 21.07.16.
  */

import javax.swing._
import java.awt.event._

class WebApplet extends JApplet {

  def find(parametr:User) : String = {
    parametr match {
      case null =>
        return "Report: User not found\n"

      case _ =>
        return "Report: User not found\n"
    }
  }

  val testStorage = new AbstractStorage()
  val testManager = new UserManager(testStorage)

  override def init() {

    val addUserButton = new JButton("Add User")
    val delUserButton = new JButton("Del User")
    val showUserButton = new JButton("Show User")

    val addUserText = new JTextArea()
    val delUserText = new JTextArea()
    val showUserText = new JTextArea()

    val commonText = new JTextArea()

    addUserButton.addActionListener(new ActionListener() {
      def actionPerformed(e: ActionEvent) {
        val str = addUserText.getText()

        commonText.setText(null)
        commonText.append("User: " + str + "\n")

        val newUser = new User(str)

        commonText.append("User.name: " + newUser.userName_ + "\n")

        testManager.addUser(newUser)

        commonText.append("complete\n")


      }
    } )

    delUserButton.addActionListener(new ActionListener() {
      def actionPerformed(e: ActionEvent) {
        val str = delUserText.getText()

        commonText.setText(null);
        commonText.append("Del User: " + str + "\n")
      }
    } )

    showUserButton.addActionListener(new ActionListener() {
      def actionPerformed(e: ActionEvent) {
        var str = showUserText.getText()

        val testUser1 = new User(str)

        str = find(testManager.getUser(testUser1))

        commonText.setText(null);
        commonText.append("Show User: " + str + "\n")
      }
    } )

    val panel = new JPanel()

    panel.setLayout(null);

    addUserButton.setLocation(50, 100);
    addUserButton.setSize(200, 50);

    addUserText.setLocation(250, 100);
    addUserText.setSize(200, 50);


    delUserButton.setLocation(50, 200);
    delUserButton.setSize(200, 50);

    delUserText.setLocation(250, 200);
    delUserText.setSize(200, 50)


    showUserButton.setLocation(50, 300);
    showUserButton.setSize(200, 50);

    showUserText.setLocation(250, 300);
    showUserText.setSize(200, 50);

    commonText.setLocation(500, 100);
    commonText.setSize(300, 250);


    panel.add(addUserButton)
    panel.add(delUserButton)
    panel.add(showUserButton)

    panel.add(addUserText)
    panel.add(delUserText)
    panel.add(showUserText)
    panel.add(commonText)

    getContentPane().add(panel)

  }

  override def start() {}
  override def stop() {}
}
