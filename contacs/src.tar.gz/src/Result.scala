/**
  * Created by randy on 03.01.16.
  */
class Result {
  /* wip */
}
